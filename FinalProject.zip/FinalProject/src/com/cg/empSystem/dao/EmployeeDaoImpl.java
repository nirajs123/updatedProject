package com.cg.empSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{
	private DBUtil util;
	
	public EmployeeDaoImpl() throws EmployeeException {
		util = new DBUtil();
	}

	//Start Of Add Employee details
	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		int status = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = util.getConnection();
			String query = "INSERT INTO EMPLOYEE VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, emp.getEmpId());
			pstmt.setString(2, emp.getEmpFname());
			pstmt.setString(3, emp.getEmpLname());
			pstmt.setDate(4, emp.getEmpDateOfBirth());
			pstmt.setDate(5, emp.getEmpDateOfJoining());
			pstmt.setInt(6, emp.getEmpDeptId());
			pstmt.setString(7, emp.getEmpGrade());
			pstmt.setInt(8, emp.getEmpBasic());
			pstmt.setString(9, emp.getEmpDesignation());
			pstmt.setString(10, emp.getEmpGender());
			pstmt.setString(11, emp.getEmpMaritalStatus());
			pstmt.setString(12, emp.getEmpHomeAddress());
			pstmt.setString(13, emp.getEmpContactNo());
			status = pstmt.executeUpdate();
			if (status == 1) {
				System.out.println("data inserted");
			} else {
				System.out.println("data not inserted");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed", e);
			}
		}
		return status;
	}//End Of Add Employee
	
	//Start Of Remove Employee details
	@Override
	public boolean RemoveEmployeeDetails(String empId) throws EmployeeException, SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int rec = 0;
		
		try {
			Employee employee=this.searchEmployeeOnId(empId);
			if(empId.equals(employee.getEmpId())){
			String query = "DELETE FROM EMPLOYEE where EMP_ID=?";
			conn = util.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, empId);
			rec = pstmt.executeUpdate();
			if (rec > 0)
			{
				return true;
			}
			}
			
		} catch (SQLException|NullPointerException e) {
			System.out.println(e);
			
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
				throw new EmployeeException("Data Not Removed",e);
			}

		}
		return false;
		
	}//End Of Remove Employee Details
	
	//Start of Show All
	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		List<Employee> myEmp = new ArrayList<Employee>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "SELECT EMP_ID, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_DATE_OF_BIRTH, EMP_DATE_OF_JOINING, EMP_DEPT_ID, EMP_GRADE, EMP_DESIGNATION,EMP_BASIC, EMP_GENDER, EMP_MARITAL_STATUS, EMP_HOME_ADDRESS, EMP_CONTACT_NUM FROM EMPLOYEE";
		try {
			
			conn = util.getConnection();
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Employee e = new Employee();
				e.setEmpId(rs.getString("EMP_ID"));
				e.setEmpFname(rs.getString("EMP_FIRST_NAME"));
				e.setEmpLname(rs.getString("EMP_LAST_NAME"));
				e.setEmpDateOfBirth(rs.getDate("EMP_DATE_OF_BIRTH"));
				e.setEmpDateOfJoining(rs.getDate("EMP_DATE_OF_JOINING"));
				e.setEmpDeptId(rs.getInt("EMP_DEPT_ID"));
				e.setEmpGrade(rs.getString("EMP_GRADE"));
				e.setEmpDesignation(rs.getString("EMP_DESIGNATION"));
				e.setEmpBasic(rs.getInt("EMP_BASIC"));
				e.setEmpGender(rs.getString("EMP_GENDER"));
				e.setEmpMaritalStatus(rs.getString("EMP_MARITAL_STATUS"));
				e.setEmpHomeAddress(rs.getString("EMP_HOME_ADDRESS"));
				e.setEmpContactNo(rs.getString("EMP_CONTACT_NUM"));
				
				myEmp.add(e);
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("problem in show");

		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}
		return myEmp;
	}//End Of Show All
	
	//Start of Login
	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException {
		System.out.println(userName);
		Connection conn = null;
		PreparedStatement pstmt = null;
		boolean flag = false;
		String result = null;
		ResultSet rs = null;
		try {
			String query = "select UserName,UserType  from User_Master";

			System.out.println("hiiiii");
			conn = util.getConnection();
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				if (rs.getString("UserName").equals(userName)) {
					result = rs.getString("UserType");
				}
			}
		} catch (SQLException e) {
			throw new EmployeeException(
					"problem in FINDING USERNAME (isValid  DAO)" + e);
		}// end of name checking
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed", e);
			}
		}
		if (result != null) {
			String query = "select UserPassword   from User_Master where UserName=? ";
			try {
				conn = util.getConnection();
				pstmt = conn.prepareStatement(query);
				pstmt.setString(1, userName);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					if (userPassword.equals(rs.getString("UserPassword"))) {
						System.out.println("pass");
						flag = true;
					}
				}

			} catch (SQLException e) {
				throw new EmployeeException(
						"problem in FINDING admin password (isValid  DAO)" + e);
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (pstmt != null) {
						pstmt.close();
					}
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException e) {
					throw new EmployeeException("Database closing failed", e);
				}
			}

			if (flag == true && result.equals("admin")) {
				return 1;
			} else if (flag == true && result.equals("employee")) {
				return 2;
			} else {
				return 0;
			}
		}
		return 3;

	}// end of isValid

	//Start Of search Employee on id
	@Override
	public Employee searchEmployeeOnId(String EmpId) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		String query="SELECT EMP_FIRST_NAME,EMP_LAST_NAME,EMP_DATE_OF_BIRTH,"
				+ "EMP_DATE_OF_JOINING,EMP_DEPT_ID,EMP_GRADE,EMP_DESIGNATION,EMP_BASIC,EMP_GENDER,EMP_MARITAL_STATUS,"
				+ "EMP_HOME_ADDRESS,EMP_CONTACT_NUM FROM EMPLOYEE WHERE EMP_ID=?";
		try{System.out.println("inside emp id DaoImpl");
			conn=util.getConnection();
			pstmt=conn.prepareStatement(query);
			pstmt.setString(1, EmpId);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()){System.out.println("inside emp id DaoImpl rs");
				String empFname=rs.getString("EMP_FIRST_NAME");
				String empLname=rs.getString("EMP_LAST_NAME");
				Date empDateOfBirth=rs.getDate("EMP_DATE_OF_BIRTH");
				Date empDateOfJoining=rs.getDate("EMP_DATE_OF_JOINING");
				int empDeptId=rs.getInt("EMP_DEPT_ID");
				String empGrade=rs.getString("EMP_GRADE");
				String empDesignation=rs.getString("EMP_DESIGNATION");
				int empBasic=rs.getInt("EMP_BASIC");
				String empGender=rs.getString("EMP_GENDER");
				String empMaritalStatus=rs.getString("EMP_MARITAL_STATUS");
				String empHomeAddress=rs.getString("EMP_HOME_ADDRESS");
				String empContactNo=rs.getString("EMP_CONTACT_NUM");
				
				Employee employee=new Employee(EmpId,empFname,empLname,empDateOfBirth,empDateOfJoining,
						empDeptId,empGrade,empDesignation,empBasic,empGender,empMaritalStatus,empHomeAddress,empContactNo);
				System.out.println(employee);
				return employee;
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("Employee id does not exist");
			
		}finally{
			try {
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}
		return null;
	}//End Of Search Employee on id

	//Start of search Employee Based On First name
	@SuppressWarnings("unused")
	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)
			throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String fname=null;
		List<Employee> elist=new ArrayList<Employee>();
		String query="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,EMP_DATE_OF_BIRTH,"
				+ "EMP_DATE_OF_JOINING,EMP_DEPT_ID,EMP_BASIC,EMP_GRADE,EMP_DESIGNATION,EMP_GENDER,EMP_MARITAL_STATUS,"
				+ "EMP_HOME_ADDRESS,EMP_CONTACT_NUM FROM EMPLOYEE WHERE EMP_FIRST_NAME LIKE ?";
		
		try{
			if(firstName.contains("?"))
			{
			fname=firstName.replace('?','_');
			System.out.println(fname);
			}
			else
			{	if(firstName.contains(" "))
				{
				fname=firstName.replace(' ','%');
				System.out.println(fname);
				}
				else
				{
				fname=firstName.replace('*','%');
				System.out.println(fname);
				}
			}
			conn=util.getConnection();
			pstmt=conn.prepareStatement(query);
			pstmt.setString(1, "%"+fname+"%");
			rs=pstmt.executeQuery();
			while(rs.next()){
				
				String empId=rs.getString("EMP_ID");
				String empFname=rs.getString("EMP_FIRST_NAME");
				String empLname=rs.getString("EMP_LAST_NAME");
				Date empDateOfBirth=rs.getDate("EMP_DATE_OF_BIRTH");
				Date empDateOfJoining=rs.getDate("EMP_DATE_OF_JOINING");
				int empDeptId=rs.getInt("EMP_DEPT_ID");
				String empGrade=rs.getString("EMP_GRADE");
				String empDesignation=rs.getString("EMP_DESIGNATION");
				int empBasic=rs.getInt("EMP_BASIC");
				String empGender=rs.getString("EMP_GENDER");
				String empMaritalStatus=rs.getString("EMP_MARITAL_STATUS");
				String empHomeAddress=rs.getString("EMP_HOME_ADDRESS");
				String empContactNo=rs.getString("EMP_CONTACT_NUM");
				Employee employee=new Employee(empId,empFname,empLname,empDateOfBirth,empDateOfJoining,empDeptId,empGrade,empDesignation,empBasic,empGender,empMaritalStatus,empHomeAddress,empContactNo);
				elist.add(employee);
				
				if(elist!=null)
				{
					return elist;
				}
				else
				{
					return null;
				
				}
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("Employee First Name Not Valid does not exist");
			
		}finally{
			try {
				if(rs!=null)
				{
					rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}
		return null;
	}//End of Search Employee Based On First name
		
	

	//Start Of Search Employee On LastName
	@SuppressWarnings("unused")
	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)
			throws EmployeeException {
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String lname=null;
		List<Employee> elist=new ArrayList<Employee>();
		String query="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,EMP_DATE_OF_BIRTH,"
				+ "EMP_DATE_OF_JOINING,EMP_DEPT_ID,EMP_GRADE,EMP_DESIGNATION,EMP_BASIC,EMP_GENDER,EMP_MARITAL_STATUS,"
				+ "EMP_HOME_ADDRESS,EMP_CONTACT_NUM FROM EMPLOYEE WHERE EMP_LAST_NAME LIKE ?";
		
		try{
			if(lastName.contains("?"))
			{
			lname=lastName.replace('?','_');
			System.out.println(lname);
			}
			else
			{	if(lastName.contains(" "))
				{
				lname=lastName.replace(' ','%');
				System.out.println(lname);
				}
				else
				{
				lname=lastName.replace('*','%');
				System.out.println(lname);
				}
			}
			conn=util.getConnection();
			pstmt=conn.prepareStatement(query);
			pstmt.setString(1, "%"+lname+"%");
			rs=pstmt.executeQuery();
			while(rs.next()){
				 
				String empId=rs.getString("EMP_ID");
				String empFname=rs.getString("EMP_FIRST_NAME");
				String empLname=rs.getString("EMP_LAST_NAME");
				Date empDateOfBirth=rs.getDate("EMP_DATE_OF_BIRTH");
				Date empDateOfJoining=rs.getDate("EMP_DATE_OF_JOINING");
				int empDeptId=rs.getInt("EMP_DEPT_ID");
				String empGrade=rs.getString("EMP_GRADE");
				String empDesignation=rs.getString("EMP_DESIGNATION");
				int empBasic=rs.getInt("EMP_BASIC");
				String empGender=rs.getString("EMP_GENDER");
				String empMaritalStatus=rs.getString("EMP_MARITAL_STATUS");
				String empHomeAddress=rs.getString("EMP_HOME_ADDRESS");
				String empContactNo=rs.getString("EMP_CONTACT_NUM");
				Employee employee=new Employee(empId,empFname,empLname,empDateOfBirth,empDateOfJoining,empDeptId,empGrade,empDesignation,empBasic,empGender,empMaritalStatus,empHomeAddress,empContactNo);
				elist.add(employee);
				
				if(elist!=null)
				{
					return elist;
				}
				else
				{
					return null;
				
				}
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("Employee Last Name Not Valid does not exist");
			
		}finally{
			try {
				if(rs!=null)
				{
					rs.close();
				}
				if(pstmt!=null){
					pstmt.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				throw new EmployeeException("Database closing failed");
			}
		}
		return null;
	}//End Of Search Employee On LastName

	//Start Of Search Employee On DepartMent
	@Override
	public List<Employee> searchEmployeeOnDepartment(String empDept1, String empDept2, String empDept3, String empDept4, String empDept5, String empDept6)
			throws EmployeeException { System.out.println("in dao showw alll dep[y parth");
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String lname=null;
		List<Employee> elist=new ArrayList<Employee>();
		String query="SELECT E.EMP_ID,E.EMP_FIRST_NAME,E.EMP_LAST_NAME,E.EMP_DATE_OF_BIRTH,"
				+ "E.EMP_DATE_OF_JOINING,E.EMP_DEPT_ID,E.EMP_BASIC,E.EMP_GRADE,E.EMP_DESIGNATION,E.EMP_GENDER,E.EMP_MARITAL_STATUS,"
				+ "E.EMP_HOME_ADDRESS,E.EMP_CONTACT_NUM,D.DEPT_NAME FROM EMPLOYEE E, DEPARTMENT D "
				+ "WHERE E.EMP_DEPT_ID=D.DEPT_ID AND (D.DEPT_NAME=? OR D.DEPT_NAME=? OR D.DEPT_NAME=? OR D.DEPT_NAME=? OR D.DEPT_NAME=? OR D.DEPT_NAME=?)";
		try{
		conn=util.getConnection();
		pstmt=conn.prepareStatement(query);
		pstmt.setString(1,empDept1);
		pstmt.setString(2,empDept2);
		pstmt.setString(3,empDept3);
		pstmt.setString(4,empDept4);
		pstmt.setString(5,empDept5);
		pstmt.setString(6,empDept6);
		rs=pstmt.executeQuery();
		while(rs.next()){
			 
			String empId=rs.getString(1);
			String empFname=rs.getString(2);
			String empLname=rs.getString(3);
			Date empDateOfBirth=rs.getDate(4);
			Date empDateOfJoining=rs.getDate(5);
			int empDeptId=rs.getInt(6);
			int empBasic=rs.getInt(7);
			String empGrade=rs.getString(8);
			String empDesignation=rs.getString(9);
			
			String empGender=rs.getString(10);
			String empMaritalStatus=rs.getString(11);
			String empHomeAddress=rs.getString(12);
			String empContactNo=rs.getString(13);
			String departmenttName=rs.getString(14);
			Department dept=new Department();
			
			dept.setDeptName(departmenttName);
			dept.setDeptId(empDeptId);
			Employee employee=new Employee(empId,empFname,empLname,empDateOfBirth,empDateOfJoining,empDeptId,empGrade,empDesignation,empBasic,empGender,empMaritalStatus,empHomeAddress,empContactNo,dept);
		
			elist.add(employee);
			System.out.println(elist);
		}
		if(elist!=null)
		{
			return elist;
		}
	}	
	catch (SQLException e) {
		e.printStackTrace();
		throw new EmployeeException("Employee Last Name Not Valid does not exist");
		
	}finally{
		try {
			if(rs!=null)
			{
				rs.close();
			}
			if(pstmt!=null){
				pstmt.close();
			}
			if(conn!=null){
				conn.close();
			}
		} catch (SQLException e) {
			throw new EmployeeException("Database closing failed");
		}
	}
	return null;

	}//End Of Search Employee On Department

	//Start Of Search Employee On Grade
	@Override
	public List<Employee> searchEmployeeOnGrade(String grade1, String grade2, String grade3, String grade4, String grade5, String grade6, String grade7)
			throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String lname=null;
		List<Employee> elist=new ArrayList<Employee>();
		String query="SELECT E.EMP_ID,E.EMP_FIRST_NAME,E.EMP_LAST_NAME,E.EMP_DATE_OF_BIRTH,"
				+ "E.EMP_DATE_OF_JOINING,E.EMP_DEPT_ID,E.EMP_BASIC,E.EMP_GRADE,E.EMP_DESIGNATION,E.EMP_GENDER,E.EMP_MARITAL_STATUS,"
				+ "E.EMP_HOME_ADDRESS,E.EMP_CONTACT_NUM,G.DESCRIPTION,G.MIN_SALARY,G.MAX_SALARY FROM EMPLOYEE E, GRADE_MASTER G "
				+ "WHERE E.EMP_GRADE=G.GRADE_CODE AND (G.GRADE_CODE=? OR G.GRADE_CODE=? OR G.GRADE_CODE=? OR  G.GRADE_CODE=? OR G.GRADE_CODE=? OR G.GRADE_CODE=? OR G.GRADE_CODE=?)";
		try{
		conn=util.getConnection();
		pstmt=conn.prepareStatement(query);
		pstmt.setString(1,grade1);
		pstmt.setString(2,grade2);
		pstmt.setString(3,grade3);
		pstmt.setString(4,grade4);
		pstmt.setString(5,grade5);
		pstmt.setString(6,grade6);
		pstmt.setString(7,grade7);
		rs=pstmt.executeQuery();
		while(rs.next()){
			 
			String empId=rs.getString(1);
			String empFname=rs.getString(2);
			String empLname=rs.getString(3);
			Date empDateOfBirth=rs.getDate(4);
			Date empDateOfJoining=rs.getDate(5);
			int empDeptId=rs.getInt(6);
			int empBasic=rs.getInt(7);
			String empGrade=rs.getString(8);
			String empDesignation=rs.getString(9);
			String empGender=rs.getString(10);
			String empMaritalStatus=rs.getString(11);
			String empHomeAddress=rs.getString(12);
			String empContactNo=rs.getString(13);
			String gradeDesc=rs.getString(14);
			int gradeMinSal=rs.getInt(15);
			int gradeMaxSal=rs.getInt(16);
			Grade gr=new Grade(empGrade,gradeDesc,gradeMinSal,gradeMaxSal);		
			Employee employee=new Employee(empId,empFname,empLname,empDateOfBirth,empDateOfJoining,empDeptId,empGrade,empDesignation,empBasic,empGender,empMaritalStatus,empHomeAddress,empContactNo,gr);
		
			elist.add(employee);	
		}
		if(elist!=null)
		{
			return elist;
		}
	}	
	catch (SQLException e) {
		e.printStackTrace();
		throw new EmployeeException("Employee Last Name Not Valid does not exist");
		
	}finally{
		try {
			if(rs!=null)
			{
				rs.close();
			}
			if(pstmt!=null){
				pstmt.close();
			}
			if(conn!=null){
				conn.close();
			}
		} catch (SQLException e) {
			throw new EmployeeException("Database closing failed");
		}
	}
		return null;
	}//End Of Search Employee On Grade

	//Start Of Search Employee On Marital Status
	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String status1, String status2, String status3, String status4, String status5) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String lname=null;
		List<Employee> elist=new ArrayList<Employee>();
		String query="SELECT EMP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,EMP_DATE_OF_BIRTH,"
				+ "EMP_DATE_OF_JOINING,EMP_DEPT_ID,EMP_GRADE,EMP_DESIGNATION,EMP_BASIC,EMP_GENDER,EMP_MARITAL_STATUS,"
				+ "EMP_HOME_ADDRESS,EMP_CONTACT_NUM FROM EMPLOYEE WHERE EMP_MARITAL_STATUS= ? OR EMP_MARITAL_STATUS= ? OR EMP_MARITAL_STATUS= ? OR EMP_MARITAL_STATUS= ? OR EMP_MARITAL_STATUS= ?";
		try{
		conn=util.getConnection();
		pstmt=conn.prepareStatement(query);
		pstmt.setString(1,status1);
		pstmt.setString(2,status2);
		pstmt.setString(3,status3);
		pstmt.setString(4,status4);
		pstmt.setString(5,status5);
		rs=pstmt.executeQuery();
		while(rs.next()){
			 
			String empId=rs.getString("EMP_ID");
			String empFname=rs.getString("EMP_FIRST_NAME");
			String empLname=rs.getString("EMP_LAST_NAME");
			Date empDateOfBirth=rs.getDate("EMP_DATE_OF_BIRTH");
			Date empDateOfJoining=rs.getDate("EMP_DATE_OF_JOINING");
			int empDeptId=rs.getInt("EMP_DEPT_ID");
			String empGrade=rs.getString("EMP_GRADE");
			String empDesignation=rs.getString("EMP_DESIGNATION");
			int empBasic=rs.getInt("EMP_BASIC");
			String empGender=rs.getString("EMP_GENDER");
			String empMaritalStatus=rs.getString("EMP_MARITAL_STATUS");
			String empHomeAddress=rs.getString("EMP_HOME_ADDRESS");
			String empContactNo=rs.getString("EMP_CONTACT_NUM");
			Employee employee=new Employee(empId,empFname,empLname,empDateOfBirth,empDateOfJoining,empDeptId,empGrade,empDesignation,empBasic,empGender,empMaritalStatus,empHomeAddress,empContactNo);
			elist.add(employee);
		}
		if(elist!=null)
		{
			return elist;
		}
		
		
	}catch (SQLException e) {
		e.printStackTrace();
		throw new EmployeeException("Employee Last Name Not Valid does not exist");
		
	}finally{
		try {
			if(rs!=null)
			{
				rs.close();
			}
			if(pstmt!=null){
				pstmt.close();
			}
			if(conn!=null){
				conn.close();
			}
		} catch (SQLException e) {
			throw new EmployeeException("Database closing failed");
		}
	}
	return null;
	}//End Of Search Employee On Marital Status

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		int upt=0;
		Connection conn = null;
		PreparedStatement pstm = null;
		String query="UPDATE EMPLOYEE SET EMP_FIRST_NAME=?,"
				+ "EMP_LAST_NAME=?,EMP_DATE_OF_BIRTH=?,"
				+ "EMP_DATE_OF_JOINING=?,EMP_DEPT_ID=?,"
				+ "EMP_GRADE=?,EMP_DESIGNATION=?,"
				+ "EMP_BASIC=?,EMP_GENDER=?,EMP_MARITAL_STATUS=?,"
				+ "EMP_HOME_ADDRESS=?,EMP_CONTACT_NUM=? WHERE EMP_ID=?";
		try {			System.out.println("in dao update p");

			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,emp.getEmpFname());
			pstm.setString(2,emp.getEmpLname());
			pstm.setDate(3,emp.getEmpDateOfBirth());
			pstm.setDate(4, emp.getEmpDateOfJoining());
			pstm.setInt(5,emp.getEmpDeptId());
			pstm.setString(6, emp.getEmpGrade());
			pstm.setString(7, emp.getEmpDesignation());
			pstm.setInt(8, emp.getEmpBasic());
			pstm.setString(9,emp.getEmpGender());
			pstm.setString(10,emp.getEmpMaritalStatus());
			pstm.setString(11,emp.getEmpHomeAddress());
			pstm.setString(12,emp.getEmpContactNo());
			pstm.setString(13,emp.getEmpId());
			 upt=pstm.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				pstm.close();
	            conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
		return emp;
	}

	

}
