package com.cg.empSystem.controller;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.service.EmployeeService;
import com.cg.empSystem.service.EmployeeServiceImpl;

@WebServlet("*.do")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService empService = null;
 
    
    public EmployeeServlet() throws EmployeeException {
        empService = new EmployeeServiceImpl();
        
    }

    
    
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
		}
	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException, EmployeeException, SQLException {
		String path = request.getServletPath();
		System.out.println(path);
		if(path.equals("/login.do")){
			RequestDispatcher dispatch = request.getRequestDispatcher("login.jsp");
		 	dispatch.forward(request, response);
		}
		else if(path.equals("/authenticate.do")){
			System.out.println("inside admin login controller");
			String userName = request.getParameter("userName");
			String password = request.getParameter("password");
			// System.out.println(adminName);
			// System.out.println(adminPass);
			int res = empService.isValid(userName, password);
			System.out.println(res);
			if (res == 0) {
				request.setAttribute("errorMsg", "oopss wrong password!!!!!! ");
				RequestDispatcher dispatch = request
						.getRequestDispatcher("login.jsp");
				dispatch.forward(request, response);

			}
			if (res == 1) {

				RequestDispatcher dispatch = request
						.getRequestDispatcher("admin.jsp");
				dispatch.forward(request, response);
			}

			if (res == 2) {

				RequestDispatcher dispatch = request
						.getRequestDispatcher("employee.jsp");
				dispatch.forward(request, response);
			}

			if (res == 3) {

				request.setAttribute("errorMsg", "oopss wrong username!!!!!! ");
				RequestDispatcher dispatch = request
						.getRequestDispatcher("login.jsp");
				dispatch.forward(request, response);

			}

		}// end of Authentication
		
		else if(path.equals("/addEmployee.do")){
			try {Employee emp =  new Employee();

				emp.setEmpId(request.getParameter("empId"));
				emp.setEmpFname(request.getParameter("empFname"));
				emp.setEmpLname(request.getParameter("empLname"));
				String dstr1 = request.getParameter("empDateOfBirth");
				Date d1 = Date.valueOf(dstr1);
				emp.setEmpDateOfBirth(d1);
				String dstr2 = request.getParameter("empDateOfJoining");
				Date d2 = Date.valueOf(dstr2);
				emp.setEmpDateOfJoining(d2);
				emp.setEmpDeptId(Integer.parseInt(request
						.getParameter("empDeptId")));
				emp.setEmpGrade(request.getParameter("empGrade"));
				emp.setEmpDesignation(request.getParameter("empDesignation"));
				emp.setEmpBasic(Integer.parseInt(request.getParameter("empBasic")));
				emp.setEmpContactNo(request.getParameter("empContactNo"));
				emp.setEmpGender(request.getParameter("empGender"));
				emp.setEmpMaritalStatus(request.getParameter("empMaritalStatus"));
				emp.setEmpHomeAddress(request.getParameter("empHomeAddress"));
				int st = empService.addEmployeeDetails(emp);
				if (st == 1) {
					RequestDispatcher dispatch = request
							.getRequestDispatcher("added.jsp");
					dispatch.forward(request, response);
				} else {
					request.setAttribute("errorMsg","Error in adding employee data");
					RequestDispatcher dispatch = request
							.getRequestDispatcher("error.jsp");
					dispatch.forward(request, response);
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
		}
		
		else if(path.equals("/deleteEmployee.do")){
			String empId=request.getParameter("empId");
			
				boolean status = empService.removeEmployeeDetails(empId);
				if(status){
				request.setAttribute("employee", empId);
				RequestDispatcher dispatch = request.getRequestDispatcher("employeeDeleted.jsp");
				dispatch.forward(request, response);
				}
				else{
					request.setAttribute("message",
							"Wrong employee Id ");
					RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
					dispatch.forward(request, response);	
				}

		

		}
		else if(path.equals("/viewAllEmp.do")){
			List<Employee> myList = empService.showAll();
			request.setAttribute("empData",myList);
			RequestDispatcher dispatch = request.getRequestDispatcher("viewAllEmp.jsp");
		 	dispatch.forward(request, response);
		}
		else if(path.equals("/getEmployeeId.do")){
			RequestDispatcher dispatch = request.getRequestDispatcher("getEmployeeId.jsp");
		 	dispatch.forward(request, response);
		}
		
		else if(path.equals("/updateForm.do")){
			String empId = request.getParameter("empId");
			
			Employee employee=empService.searchEmployeeOnId(empId);
			if(employee!=null){
				request.setAttribute("empData",employee);
			RequestDispatcher dispatch = request.getRequestDispatcher("updateForm.jsp");
		 	dispatch.forward(request, response);
			}
			else{
				RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
			 	dispatch.forward(request, response);
			}
		}
		else if(path.equals("/submitUpdateForm.do")){
			System.out.println("in contro p");
			Employee emp =  new Employee();
			
			String empId=request.getParameter("empId");
			emp.setEmpFname(request.getParameter("empFname"));
			emp.setEmpLname(request.getParameter("empLname"));
			String dstr1 = request.getParameter("empDateOfBirth");
			Date d1 = Date.valueOf(dstr1);
			emp.setEmpDateOfBirth(d1);
			emp.setEmpId(empId);
			String dstr2 = request.getParameter("empDateOfJoining");
			Date d2 = Date.valueOf(dstr2);
			emp.setEmpDateOfJoining(d2);
			emp.setEmpDeptId(Integer.parseInt(request
					.getParameter("empDeptId")));
			emp.setEmpGrade(request.getParameter("empGrade"));
			emp.setEmpDesignation(request.getParameter("empDesignation"));
			emp.setEmpBasic(Integer.parseInt(request.getParameter("empBasic")));
			emp.setEmpContactNo(request.getParameter("empContactNo"));
			emp.setEmpGender(request.getParameter("empGender"));
			emp.setEmpMaritalStatus(request.getParameter("empMaritalStatus"));
			emp.setEmpHomeAddress(request.getParameter("empHomeAddress"));
			Employee employee = empService.updateEmployee(emp);
			if (employee!=null) {
				request.setAttribute("employee",empId);
				RequestDispatcher dispatch = request
						.getRequestDispatcher("employeeUpdated.jsp");
				dispatch.forward(request, response);
			} 
			else {
				request.setAttribute("errorMsg","Error in updating employee data");
				RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
				dispatch.forward(request, response);
			}
		}
		
		//On ID
		else if (path.equals("/searchEmployeeOnId.do")) {

			try {
				Employee employee = empService.searchEmployeeOnId(request
						.getParameter("empId"));
				System.out.println(employee);
				request.setAttribute("emp", employee);
				RequestDispatcher dispatch = request.getRequestDispatcher("userList.jsp");
				dispatch.forward(request, response);

			} catch (EmployeeException e) {
				System.out.println("problem in result of  SearchEmployeeOnId");
				request.setAttribute("message",
						"OOoopss!!!!! something went wrong please try again ");
				RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnId.jsp");
				dispatch.forward(request, response);

			}

		}
		//by FIRST NAME
		else if (path.equals("/searchEmployeeOnFirstName.do")) {

			try {
				List<Employee> employee = empService.searchEmployeeOnFirstName(request
						.getParameter("empFname"));
				request.setAttribute("employee", employee);
				RequestDispatcher dispatch = request.getRequestDispatcher("employeeFirstName.jsp");
				dispatch.forward(request, response);

			} catch (EmployeeException e) {
				System.out.println("problem in result of  SearchEmployeeOnId");
				request.setAttribute("message",
						"OOoopss!!!!! something went wrong please try again ");
				RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnFirstName.jsp");
				dispatch.forward(request, response);

			}

		}
		//On Last Name
		else if (path.equals("/searchEmployeeOnLastName.do")) {

			try {
				List<Employee> employee = empService.searchEmployeeOnLastName(request
						.getParameter("empLname"));
				System.out.println(employee);
				request.setAttribute("employee", employee);
				RequestDispatcher dispatch = request.getRequestDispatcher("employeeFirstName.jsp");
				dispatch.forward(request, response);

			} catch (EmployeeException e) {
				System.out.println("problem in result of  SearchEmployeeOnId");
				request.setAttribute("message",
						"OOoopss!!!!! something went wrong please try again ");
				

			}

		}
		
		//Start of search employee on department
		else if(path.equals("/searchEmployeeOnDepartment.do")){
			
			try {
				String empDept1=request.getParameter("empDeptId1");
				String empDept2=request.getParameter("empDeptId2");
				String empDept3=request.getParameter("empDeptId3");
				String empDept4=request.getParameter("empDeptId4");
				String empDept5=request.getParameter("empDeptId5");
				String empDept6=request.getParameter("empDeptId6");
				System.out.println(empDept1);
				
			
						List<Employee> empDept=empService.searchEmployeeOnDepartment(empDept1,empDept2,empDept3,empDept4,empDept5,empDept6);	
						System.out.println(empDept);
						request.setAttribute("empDept", empDept);	
					
					RequestDispatcher dispatch=request.getRequestDispatcher("employeeDepartmentList.jsp");
					dispatch.forward(request,response);
				
			} catch (EmployeeException e) {
				System.out.println(e.getMessage());
				request.setAttribute("message", e.getMessage());
				RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnDepartment.jsp");
				dispatch.forward(request, response);
				
			}
			
		}//End of Search Employee On Department
		
		//Start of search employee on grade
		else if(path.equals("/searchEmployeeOnGrade.do")){
					
					try {
							String grade1=request.getParameter("empGrade1");
							String grade2=request.getParameter("empGrade2");
							String grade3=request.getParameter("empGrade3");
							String grade4=request.getParameter("empGrade4");
							String grade5=request.getParameter("empGrade5");
							String grade6=request.getParameter("empGrade6");
							String grade7=request.getParameter("empGrade7");
							
								List<Employee> empGrade=empService.searchEmployeeOnGrade(grade1,grade2,grade3,grade4,grade5,grade6,grade7);	
								request.setAttribute("empGrade", empGrade);
								
							
							RequestDispatcher dispatch=request.getRequestDispatcher("employeeGradeList.jsp");
							dispatch.forward(request,response);
					} catch (EmployeeException e) {
						System.out.println(e.getMessage());
						request.setAttribute("message", e.getMessage());
						RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnGrade.jsp");
						dispatch.forward(request, response);
						
					}
					
				}//End of Search Employee On grade
				
				//Start of search employee on marital status
		else if(path.equals("/searchEmployeeOnMaritalStatus.do")){
					
					try {
							String status1=request.getParameter("empMaritalStatus1");
							String status2=request.getParameter("empMaritalStatus2");
							String status3=request.getParameter("empMaritalStatus3");
							String status4=request.getParameter("empMaritalStatus4");
							String status5=request.getParameter("empMaritalStatus5");
						
							
						
					
								List<Employee> empStatus=empService.searchEmployeeOnMaritalStatus(status1,status2,status3,status4,status5);	
								System.out.println(empStatus);
								request.setAttribute("empStatus", empStatus);
							
							RequestDispatcher dispatch=request.getRequestDispatcher("employeeMaritalStatus.jsp");
							dispatch.forward(request,response);
					} catch (EmployeeException e) {
						System.out.println(e.getMessage());
						request.setAttribute("message", e.getMessage());
						RequestDispatcher dispatch = request.getRequestDispatcher("searchEmployeeOnMaritalStatus.jsp");
						dispatch.forward(request, response);
						
					}
					
				}//End of Search Employee On marital status
				
		
	}
}
